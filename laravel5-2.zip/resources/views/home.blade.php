@extends('layouts.app')

@section('content')
<div class="container">
    <h1 class="text-center">Альбомы фотогалереи</h1>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Создание нового альбома</div>

                <div class="card-body">
                        {{--<form action="{{ auth()->user()->id }}/albums" method="post" class="form-horizontal">--}}
                        <form action="{{ auth()->user()->id }}/albums" method="post" class="form-horizontal">
                            @csrf
                            <div class="form-group">
                                <label for="name">Название:</label>
                                <input type="text" name="title" id="title" value="{{ old('title') }}" class="form-control">
                            </div>

                            <button class="btn btn-primary">Добавить</button>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>

<hr>

@if (count($data) > 0)
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Существующие альбомы</div>
                <div class="card-body">
                    <table class="table table-striped task-table">
                        <tbody>
                        @foreach($data as $item)
                            <tr>
                                <td class="table-text">
                                    <div>{{ $item-> title }}</div>
                                </td>
                                <td>
                                        <p class="text-center bg-success">{{ ($item->is_public) == 0 ? "Публичный" : "" }}</p>
                                </td>
                                <td>
                                    <form action="{{url('albums/'.$item->id)}}" method="POST">
                                        @csrf
                                        <button class="btn btn-outline-success">Смотреть фото</button>
                                    </form>
                                </td>
                                <td>

                                    <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#edite_album" data-content="[ {{ $item-> id }}, {{ $item-> title }} ] ">
                                        Редактировать
                                    </button>

                                </td>
                                <td>
                                    <form action="albums/{{ $item->id }}" method="POST" >
                                        @csrf
                                        @method('DELETE')

                                        <button class="btn btn-outline-danger">Удалить</button>

                                    </form>
                                </td>
                                <td>
                                    <form>

                                        <input type="checkbox">

                                    </form>
                                </td>
                            </tr>

                            <!-- Модальное окно для редактирования -->
                            <div class="modal fade" id="edite_album" tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Редактирование альбома</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">

                                            <form action="albums/{{ $item->id }}/update" method="POST" class="form-horizontal">
                                                @csrf
                                                @method('PATCH')

                                                <div class="form-group">
                                                    <label for="name">Название:</label>
                                                    <input type="text" name="content" id="content" value="{{ $item }}" class="form-control">
                                                </div>
                                            </form>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- Модальное окно -->

                        @endforeach

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
@endif





@endsection