@extends('layouts.app')


@section('content')
    <h1><center>Главная страница проекта Фотогалерея</center></h1>
@endsection
