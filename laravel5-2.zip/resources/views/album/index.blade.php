@extends('app')

@section('content')
Привет
    @stop
