<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Album;

class AlbumController extends Controller
{

    public function index()
    {
        $data=auth()->user()->albums;
        return (view('home', ['data' => $data]));

    }

    public function store(Request $request)
    {
        auth()->user()->albums()->create($request->all());
        return redirect('home');

//     dd($request->get('title'));
//     dd(auth()->user()->id);

    }

    public function destroy(Album $album)
    {
        $album->delete();
        return redirect('home');
    }


    public function update()
    {
                dd('123');

        //        dd($request->get('title'));
//        $album->update($request->all());
//        return redirect('home');
    }






}

