<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-center">Альбомы фотогалереи</h1>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Создание нового альбома</div>

                <div class="card-body">
                        
                        <form action="<?php echo e(auth()->user()->id); ?>/albums" method="post" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Название:</label>
                                <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>" class="form-control">
                            </div>

                            <button class="btn btn-primary">Добавить</button>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>

<hr>

<?php if(count($data) > 0): ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Существующие альбомы</div>
                <div class="card-body">
                    <table class="table table-striped task-table">
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="table-text">
                                    <div><?php echo e($item-> title); ?></div>
                                </td>
                                <td>
                                        <p class="text-center bg-success"><?php echo e(($item->is_public) == 0 ? "Публичный" : ""); ?></p>
                                </td>
                                <td>
                                    <form action="<?php echo e(url('albums/'.$item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-outline-success">Смотреть фото</button>
                                    </form>
                                </td>
                                <td>

                                    <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#edite_album" data-content="[ <?php echo e($item-> id); ?>, <?php echo e($item-> title); ?> ] ">
                                        Редактировать
                                    </button>

                                </td>
                                <td>
                                    <form action="albums/<?php echo e($item->id); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button class="btn btn-outline-danger">Удалить</button>

                                    </form>
                                </td>
                                <td>
                                    <form>

                                        <input type="checkbox">

                                    </form>
                                </td>
                            </tr>

                            <!-- Модальное окно для редактирования -->
                            <div class="modal fade" id="edite_album" tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Редактирование альбома</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">

                                            <form action="albums/<?php echo e($item->id); ?>/update" method="POST" class="form-horizontal">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>

                                                <div class="form-group">
                                                    <label for="name">Название:</label>
                                                    <input type="text" name="content" id="content" value="<?php echo e($item); ?>" class="form-control">
                                                </div>
                                            </form>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- Модальное окно -->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php endif; ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel5\resources\views/home.blade.php ENDPATH**/ ?>