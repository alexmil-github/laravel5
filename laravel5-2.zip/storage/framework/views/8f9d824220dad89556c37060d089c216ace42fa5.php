<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Новый альбом</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(auth()->user()->id); ?>/albums" method="post" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Название:</label>
                        <input type="text" name="title" id="title" value="<?php echo e(old('name')); ?>" class="form-control">
                    </div>

                    <button class="btn btn-primary">Добавить</button>
                    </form>

                </div>
            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel5\resources\views/create_album.blade.php ENDPATH**/ ?>